from aiogram import Dispatcher, types

""" Подготовка к поиску """
async def find_text_message(message: types.Message):

    # Предложить добавить
    buttons = [
        types.InlineKeyboardButton(text="Да", callback_data="add_yes"),
        types.InlineKeyboardButton(text="Нет", callback_data="add_no"),
      ]
    keyboard = types.InlineKeyboardMarkup(row_width = 2)
    keyboard.add(*buttons)

    await message.answer("Да или Нет", reply_markup = keyboard)

""" Предложение """
async def ask_to_add(call: types.CallbackQuery):
    await call.message.answer("callback for " + call.data)
    # Не забываем отчитаться о получении колбэка
    await call.answer()
    
""" Регистрация хендлеров """
def register_handlers_find(dp: Dispatcher):
    dp.register_message_handler(find_text_message, commands="find")
    dp.callback_query_handler(ask_to_add, lambda c: c.data.startswith("a"))
